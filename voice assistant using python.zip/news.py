import requests

# Assuming `key` is defined in the imported 'ss' module
from ss import key

# Corrected API address
api_address = f'http://newsapi.org/v2/top-headlines?country=us&apiKey={key}'

# Making the API request
try:
    json_data = requests.get(api_address).json()
except requests.exceptions.RequestException as e:
    print(f"An error occurred: {e}")
    json_data = None

# Empty list to hold the top 3 news titles
ar = []

def news():
    if json_data and 'articles' in json_data:
        for i in range(min(3, len(json_data['articles']))):
            ar.append("Number " + str(i+1) + ": " + json_data['articles'][i]['title'] + '.')
    return ar

# Fetch the news and print the result
# arr = news()
# print(arr)
