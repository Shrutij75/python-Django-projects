from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException, NoSuchWindowException

class YouTube:
    def __init__(self):
        service = Service("C:\\Users\\DELL\\Downloads\\chromedriver-win64\\chromedriver.exe")
        self.driver = webdriver.Chrome(service=service)

    def play(self, query):
        try:
            self.driver.get("https://www.youtube.com/results?search_query=" + query)
            
            # Wait until the video elements are loaded and clickable
            wait = WebDriverWait(self.driver, 10)
            video = wait.until(EC.element_to_be_clickable((By.XPATH, '(//*[@id="dismissable"])[1]')))
            video.click()
        except (NoSuchElementException, TimeoutException) as e:
            print(f"Error: {e}")
        except NoSuchWindowException:
            print("Browser window was closed prematurely.")
        finally:
            # Close the browser only after ensuring all interactions are complete
            if self.driver:
                self.driver.quit()

# Usage
# yt = YouTube()
# yt.play("Python tutorial")
