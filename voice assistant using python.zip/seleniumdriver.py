from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

class Infow():
    def __init__(self):
        # Initialize the ChromeDriver service
        service = Service("C:\\Users\\DELL\\Downloads\\chromedriver-win64\\chromedriver.exe")
        self.driver = webdriver.Chrome(service=service)
        
    def get_info(self, query):
        # Open Wikipedia's homepage
        self.driver.get(url="https://www.wikipedia.org")
        
        # Locate the search input element by its XPATH
        search = self.driver.find_element(By.XPATH, '//*[@id="searchInput"]')
        
        # Enter the search query into the search input field
        search.send_keys(query)
        
        # Locate and click the search button
        enter = self.driver.find_element(By.XPATH, '//*[@id="search-form"]/fieldset/button')
        enter.click()

        # Add a delay if necessary to allow the page to load fully (optional)
        # import time
        # time.sleep(3)
        
        # Close the browser after getting the information (optional)
        self.driver.quit()

# Create an instance of the Infow class
# assist = Infow()
# assist.get_info("fuzzy logic")
