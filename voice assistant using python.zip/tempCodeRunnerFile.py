'''import pyttsx3 as p
import speech_recognition as sr
engine=p.init()  #used to initialization and gets the info of the current driver

rate=engine.getProperty('rate') #gives the rate of the speech of the assistant 
# we can also chng the rate by our choice with the help of setProperty
engine.setProperty('rate',180)
# print(rate)
voices=engine.getProperty('voices')
engine.setProperty('voice',voices[1].id)
# print(voices)

def speak(text):
    engine.say(text)
    engine.runAndWait()

r=sr.Recognizer() #r is the instance of the recognizer
speak("Hello Sir, I am your voice assistant . How are you??")

with sr.Microphone() as source:
    r.energy_threshold=10000 #adjust the voice frequency
    r.adjust_for_ambient_noise(source,1.2) #it removes the extra bg noise
    print("listening.....")
    audio=r.listen(source)#it can store the traslated text from the voice
    text=r.recognize_google(audio) #it can capture the audio and then sended to goole API that translate it into text
    print(text)

if "how" and "about" and "you" in text:
    speak("I am also having a good day sir!")
speak("What can I do for You? ")

with sr.Microphone() as source:
    r.energy_threshold=10000 #adjust the voice frequency
    r.adjust_for_ambient_noise(source,1.2) #it removes the extra bg noise
    print("listening.....")
    audio=r.listen(source)
    text2=r.recognize_google(audio)
    
if "information" in text2:
    speak("You need information related to which topic")
    with sr.Microphone() as source:
        r.energy_threshold=10000 #adjust the voice frequency
        r.adjust_for_ambient_noise(source,1.2) #it removes the extra bg noise
        print("listening.....")
        audio=r.listen(source)
        infor=r.recognize_google(audio)
    
assist = Infow()
assist.get_info("infor")
'''

import pyttsx3 as p
import speech_recognition as sr
from seleniumdriver import Infow  # Import the correct class
from utube import YouTube  # Import the correct class
from news import *
import randfacts  #a predefined library used for finding the random facts from the module


engine = p.init()

engine.setProperty('rate', 180)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)

def speak(text):
    engine.say(text)
    engine.runAndWait()

r = sr.Recognizer()

speak("Hello Sir, I am your voice assistant. How are you?")

with sr.Microphone() as source:
    r.energy_threshold = 10000
    r.adjust_for_ambient_noise(source, 1.2)
    print("Listening...")
    audio = r.listen(source)
    try:
        text = r.recognize_google(audio)
        print(text)
    except sr.UnknownValueError:
        speak("Sorry, I did not understand that.")
        text = ""

if "what" in text and "about" in text and "you" in text:
    speak("I am also having a good day, sir!")

speak("What can I do for you?")

with sr.Microphone() as source:
    r.energy_threshold = 10000
    r.adjust_for_ambient_noise(source, 1.2)
    print("Listening...")
    audio = r.listen(source)
    try:
        text2 = r.recognize_google(audio)
        print(text2)
    except sr.UnknownValueError:
        speak("Sorry, I did not understand that.")
        text2 = ""

if "information" in text2:
    speak("You need information related to which topic?")
    with sr.Microphone() as source:
        r.energy_threshold = 10000
        r.adjust_for_ambient_noise(source, 1.2)
        print("Listening...")
        audio = r.listen(source)
        try:
            infor = r.recognize_google(audio)
            print(infor)
        except sr.UnknownValueError:
            speak("Sorry, I did not understand that.")
            infor = ""
    if infor:  # Check if 'infor' is not empty
        speak("Searching {} in Wikipedia".format(infor))
        assist = Infow()
        assist.get_info(infor)

elif "play" in text2 and "video" in text2:
    speak("Which video do you want to play?")
    with sr.Microphone() as source:
        r.energy_threshold = 10000
        r.adjust_for_ambient_noise(source, 1.2)
        print("Listening...")
        audio = r.listen(source)
        try:
            vid = r.recognize_google(audio)
            print(vid)
        except sr.UnknownValueError:
            speak("Sorry, I did not understand that.")
            vid = ""
    if vid:  # Check if 'vid' is not empty
        yt = YouTube()
        yt.play(vid)

# can you please read some latest news for me!!
elif "news" in text2:
    print("Sure Sir i will read news for you!!")
    speak("Sure Sir i will read news for you!!")
    arr=news()
    for i in range(len(arr)):
        print(arr[i])
        speak(arr[i])
 
elif "fact" or "facts" in text2:
    x=randfacts.getFact()
    print(x)
    speak("Did you know that, "+x)     
    