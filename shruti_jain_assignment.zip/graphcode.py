import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def generate_graph(df):
    # Convert Date column to datetime with the correct format
    df['Date'] = pd.to_datetime(df['Date'], format='%d-%m-%Y')

    # Sort the data by Date
    df = df.sort_values(by='Date')

    # Calculate 30-day moving average of PR
    df['PR_MA_30'] = df['PR'].rolling(window=30).mean()

    # Generate the budget line
    start_value = 73.9
    annual_reduction = 0.008  # 0.8% reduction per year
    budget_line = []
    
    for date in df['Date']:
        year_diff = (date.year - 2019) + (date.month - 7) / 12
        budget_value = start_value * (1 - annual_reduction) ** year_diff
        budget_line.append(budget_value)
    
    df['Budget'] = budget_line

    # Scatter plot PR with GHI-based coloring
    colors = df['GHI'].apply(lambda ghi: 'navy' if ghi < 2 else 'lightblue' if ghi < 4 else 'orange' if ghi < 6 else 'brown')

    plt.figure(figsize=(14, 8))
    
    # Scatter plot
    plt.scatter(df['Date'], df['PR'], c=colors, label='Daily PR', alpha=0.7)
    
    # Plot 30-day moving average (red line)
    plt.plot(df['Date'], df['PR_MA_30'], color='red', label='30-Day Moving Average of PR', linewidth=2)
    
    # Plot budget line (dark green line)
    plt.plot(df['Date'], df['Budget'], color='darkgreen', label='Budget Line', linewidth=2, linestyle='--')
    
    # Highlight points above the budget line
    above_budget = df[df['PR'] > df['Budget']]
    plt.scatter(above_budget['Date'], above_budget['PR'], color='lime', edgecolor='black', label='PR above Budget', s=100, marker='o')

    # Add legend
    plt.legend(loc='upper left')

    # Display average PR values for the last 7, 30, 60 days, etc.
    time_windows = [7, 30, 60, 90, 180, 365]
    averages = [df['PR'].rolling(window=days).mean().iloc[-1] for days in time_windows]
    
    textstr = '\n'.join([f'Avg PR last {days} days: {avg:.2f}' for days, avg in zip(time_windows, averages)])
    
    plt.text(0.95, 0.05, textstr, transform=plt.gca().transAxes, fontsize=10,
             verticalalignment='bottom', horizontalalignment='right', bbox=dict(facecolor='white', alpha=0.5))

    # Set labels and title
    plt.xlabel('Date')
    plt.ylabel('PR')
    plt.title('PR Evolution with Budget Line and GHI Coloring')

    # Show grid
    plt.grid(True)

    # Show the plot
    plt.show()

# Example usage:
# Assuming 'df' is the DataFrame containing the Date, GHI, and PR columns
df = pd.read_csv("C:\\Users\\DELL\\Desktop\\outputfile.csv")  # Load your data
generate_graph(df)
