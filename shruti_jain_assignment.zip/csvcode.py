import pandas as pd
import os
import glob

def merge_data(folder_path, column_name):
    # Use glob to find all CSV files in the folder and its subfolders
    all_files = glob.glob(os.path.join(folder_path, "**", "*.csv"), recursive=True)
    
    # Initialize an empty list to hold the dataframes
    data_list = []
    
    # Check if there are any files to process
    if not all_files:
        raise ValueError(f"No CSV files found in the folder: {folder_path}")

    # Loop through each file, read it, and store it in the list
    for file in all_files:
        try:
            df = pd.read_csv(file)
            if df.empty:
                print(f"File is empty and will be skipped.")
                continue
            df.columns = ['Date', column_name]  # Rename the columns
            data_list.append(df)
        except Exception as e:
            print(f"Error reading {file}: {e}")

    # Concatenate all the dataframes into one
    combined_df = pd.concat(data_list, ignore_index=True)
    return combined_df

def preprocess_data(pr_folder, ghi_folder, output_file):
    # Step 1: Read and merge PR data
    pr_data = merge_data(pr_folder, 'PR')

    # Step 2: Read and merge GHI data
    ghi_data = merge_data(ghi_folder, 'GHI')

    # Step 3: Merge PR and GHI data on Date
    merged_data = pd.merge(pr_data, ghi_data, on='Date', how='inner')

    # Step 4: Save the merged data to a CSV file
    merged_data.to_csv(output_file, index=False)


# Define paths to the PR and GHI folders and the output file
pr_folder ="C:\\Users\\DELL\\Downloads\\PR"
ghi_folder = "C:\\Users\\DELL\\Downloads\\GHI"
output_file = "C:\\Users\\DELL\\Desktop\\outputfile.csv"

# Call the preprocessing function
preprocess_data(pr_folder, ghi_folder, output_file)
